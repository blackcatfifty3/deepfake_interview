#!/bin/bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
MODEL_NAME="qwen3:1.7b"
WHISPER_MODEL_NAME="ggml-tiny.en.bin"
MODEL_PATH="$ROOT/models/$WHISPER_MODEL_NAME"
WHISPER_DIR="$ROOT/bin/whisper.cpp"
LOG_DIR="$ROOT/logs"
mkdir -p "$LOG_DIR" "$ROOT/models" "$WHISPER_DIR"

fail() {
  printf '\nINSTALLATION FAILED: %s\n' "$1" >&2
  printf 'Correct the issue above, then double-click Install.command again.\n' >&2
  read -r -p 'Press Return to close this window. ' _ || true
  exit 1
}
step() { printf '\n\033[1;36m==> %s\033[0m\n' "$1"; }

if [[ "$(uname -s)" != "Darwin" ]]; then fail 'This installer is for macOS only.'; fi
MAC_MAJOR="$(sw_vers -productVersion | cut -d. -f1)"
MAC_MINOR="$(sw_vers -productVersion | cut -d. -f2)"
if (( MAC_MAJOR < 14 )); then
  fail 'Ollama currently requires macOS Sonoma (14) or later for this setup. Update macOS or use a supported machine.'
fi
ARCH="$(uname -m)"
printf 'Mac architecture: %s\n' "$ARCH"
printf 'This installer downloads local AI models and dependencies. Keep the Mac connected to the internet.\n'
printf 'It may require your Mac login password for Homebrew / Developer Tools installation.\n'

# Homebrew requires Apple's Command Line Tools.
if ! xcode-select -p >/dev/null 2>&1; then
  printf '\nApple Command Line Tools are missing. macOS will display its installation prompt.\n'
  xcode-select --install >/dev/null 2>&1 || true
  printf 'Finish that installation, then run Install.command again.\n'
  read -r -p 'Press Return to close this window. ' _ || true
  exit 1
fi

# Install Homebrew if not already available.
if [[ -x /opt/homebrew/bin/brew ]]; then
  BREW=/opt/homebrew/bin/brew
elif [[ -x /usr/local/bin/brew ]]; then
  BREW=/usr/local/bin/brew
else
  step 'Installing Homebrew package manager'
  NONINTERACTIVE=1 /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)" || fail 'Homebrew installation failed.'
  if [[ -x /opt/homebrew/bin/brew ]]; then BREW=/opt/homebrew/bin/brew
  elif [[ -x /usr/local/bin/brew ]]; then BREW=/usr/local/bin/brew
  else fail 'Homebrew was not found after installation.'; fi
fi
eval "$("$BREW" shellenv)"

step 'Installing Python, whisper.cpp, and PortAudio'
for formula in python@3.11 whisper.cpp portaudio; do
  if "$BREW" list --versions "$formula" >/dev/null 2>&1; then
    printf 'Already installed: %s\n' "$formula"
  else
    "$BREW" install "$formula" || fail "Homebrew could not install $formula. Check the output above and rerun the installer."
  fi
done
PYTHON="$("$BREW" --prefix python@3.11)/bin/python3.11"
if [[ ! -x "$PYTHON" ]]; then PYTHON="$(command -v python3.11 || true)"; fi
[[ -n "$PYTHON" && -x "$PYTHON" ]] || fail 'Python 3.11 was not found after Homebrew installation.'
printf 'Using Python: %s\n' "$PYTHON"

step 'Installing Ollama for macOS'
OLLAMA_BIN=""
for candidate in \
  "$HOME/Applications/Ollama.app/Contents/Resources/ollama" \
  "/Applications/Ollama.app/Contents/Resources/ollama" \
  "$(command -v ollama 2>/dev/null || true)"; do
  if [[ -n "$candidate" && -x "$candidate" ]]; then OLLAMA_BIN="$candidate"; break; fi
done
if [[ -z "$OLLAMA_BIN" ]]; then
  DMG="$TMPDIR/Ollama-installer-$$.dmg"
  MOUNT="$TMPDIR/Ollama-mount-$$"
  mkdir -p "$MOUNT" "$HOME/Applications"
  step 'Downloading official Ollama app'
  curl -fL --retry 3 --progress-bar 'https://ollama.com/download/Ollama.dmg' -o "$DMG" || fail 'Could not download the official Ollama DMG.'
  hdiutil attach "$DMG" -nobrowse -quiet -mountpoint "$MOUNT" || fail 'Could not mount the Ollama DMG.'
  APP_SOURCE="$(find "$MOUNT" -maxdepth 3 -type d -name 'Ollama.app' -print -quit)"
  if [[ -z "$APP_SOURCE" ]]; then hdiutil detach "$MOUNT" -quiet || true; fail 'The Ollama DMG did not contain Ollama.app.'; fi
  ditto "$APP_SOURCE" "$HOME/Applications/Ollama.app" || fail 'Could not copy Ollama.app to ~/Applications.'
  hdiutil detach "$MOUNT" -quiet || true
  rm -rf "$MOUNT" "$DMG"
  OLLAMA_BIN="$HOME/Applications/Ollama.app/Contents/Resources/ollama"
fi
[[ -x "$OLLAMA_BIN" ]] || fail 'Ollama executable was not found. Install it from https://ollama.com/download/mac and rerun this installer.'
printf '%s\n' "$OLLAMA_BIN" > "$ROOT/.ollama_bin_path"
printf 'Using Ollama: %s\n' "$OLLAMA_BIN"

# Start the service if it isn't already answering its local API.
if ! curl -fsS --max-time 2 http://127.0.0.1:11434/api/tags >/dev/null 2>&1; then
  step 'Starting local Ollama service'
  nohup "$OLLAMA_BIN" serve >> "$LOG_DIR/ollama.log" 2>&1 < /dev/null &
  OLLAMA_PID=$!
  echo "$OLLAMA_PID" > "$ROOT/logs/ollama.pid"
  for _ in $(seq 1 90); do
    if curl -fsS --max-time 2 http://127.0.0.1:11434/api/tags >/dev/null 2>&1; then break; fi
    sleep 1
  done
fi
curl -fsS --max-time 2 http://127.0.0.1:11434/api/tags >/dev/null 2>&1 || fail 'Ollama did not start. Review logs/ollama.log and try opening Ollama.app once, then rerun Install.command.'

step "Downloading Qwen model $MODEL_NAME (several GB may be used by model/cache files)"
"$OLLAMA_BIN" pull "$MODEL_NAME" || fail "Could not download $MODEL_NAME. Check the network and free disk space, then rerun Install.command."

step 'Connecting the Homebrew Whisper CLI to this project'
WHISPER_CLI="$("$BREW" --prefix whisper.cpp)/bin/whisper-cli"
[[ -x "$WHISPER_CLI" ]] || fail "Homebrew installed whisper.cpp but whisper-cli was not found at $WHISPER_CLI."
ln -sf "$WHISPER_CLI" "$WHISPER_DIR/whisper-cli"

if [[ ! -s "$MODEL_PATH" ]] || [[ "$(stat -f%z "$MODEL_PATH" 2>/dev/null || echo 0)" -lt 50000000 ]]; then
  step 'Downloading Whisper tiny.en speech model (~75 MB)'
  rm -f "$MODEL_PATH"
  curl -fL --retry 3 --progress-bar 'https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-tiny.en.bin?download=true' -o "$MODEL_PATH" || fail 'Whisper model download failed. Rerun Install.command to retry.'
  [[ "$(stat -f%z "$MODEL_PATH")" -ge 50000000 ]] || fail 'Whisper model appears incomplete; rerun Install.command.'
else
  printf 'Found cached Whisper model.\n'
fi

step 'Creating Python environment and installing dependencies'
if [[ ! -x "$ROOT/.venv/bin/python" ]]; then
  "$PYTHON" -m venv "$ROOT/.venv" || fail 'Could not create Python virtual environment.'
fi
"$ROOT/.venv/bin/python" -m pip install --upgrade pip || fail 'Could not upgrade pip.'
"$ROOT/.venv/bin/python" -m pip install -r "$ROOT/requirements.txt" || fail 'Python dependency installation failed.'

# Ask for a key without echoing it; never package a populated key.
KEY_FILE="$ROOT/sarvam.env"
EXISTING_KEY=""
if [[ -f "$KEY_FILE" ]]; then
  EXISTING_KEY="$(sed -n 's/^SARVAM_API_KEY=//p' "$KEY_FILE" | head -n 1 | tr -d '\r')"
fi
if [[ -n "$EXISTING_KEY" && "$EXISTING_KEY" != PASTE_YOUR_SARVAM_API_KEY_HERE && "$EXISTING_KEY" != YOUR_SARVAM_API_KEY_HERE ]]; then
  printf '\nA Sarvam API key is already saved.\n'
  read -r -p 'Keep existing key? [Y/n] ' KEEP
  if [[ "${KEEP:-Y}" =~ ^[Nn]$ ]]; then EXISTING_KEY=""; fi
fi
if [[ -z "$EXISTING_KEY" || "$EXISTING_KEY" == PASTE_YOUR_SARVAM_API_KEY_HERE || "$EXISTING_KEY" == YOUR_SARVAM_API_KEY_HERE ]]; then
  printf '\nGet a key from https://dashboard.sarvam.ai/\n'
  read -r -s -p 'Paste Sarvam API key (input is hidden): ' SARVAM_KEY
  printf '\n'
  [[ -n "$SARVAM_KEY" && "$SARVAM_KEY" != *$'\n'* && "$SARVAM_KEY" != *$'\r'* ]] || fail 'No valid-looking key was entered.'
  printf '# Keep this file private; it contains your Sarvam API key.\nSARVAM_API_KEY=%s\n' "$SARVAM_KEY" > "$KEY_FILE"
  unset SARVAM_KEY
fi
chmod 600 "$KEY_FILE"

step 'Verifying files and Python syntax'
"$ROOT/.venv/bin/python" -m py_compile "$ROOT/app.py" "$ROOT/config.py" "$ROOT/ui_app.py" || fail 'Python syntax check failed.'
"$WHISPER_DIR/whisper-cli" --help >/dev/null 2>&1 || fail 'Whisper CLI did not run correctly.'

cat <<'EOF'

============================================================
 INSTALLATION COMPLETE
============================================================
Double-click "Run Interview.command" to launch the interview.
The first launch may trigger a macOS microphone permission prompt.
If microphone capture fails, allow Terminal/Python in:
System Settings > Privacy & Security > Microphone.

This is a local training simulation. Whisper and Qwen run locally;
only generated answer text is sent to Sarvam for voice synthesis.
EOF
read -r -p 'Press Return to close this window. ' _ || true
