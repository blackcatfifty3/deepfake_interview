# Local System Engineer knowledge base

This is a starter knowledge base for a demo, not a substitute for your organization's runbooks. Extend it with approved, non-sensitive troubleshooting notes before using the demo in a session.

## Network fundamentals: TCP, UDP, IP, ports, OSI
TCP is connection-oriented and provides ordered, reliable delivery using acknowledgements and retransmission. UDP is connectionless and has lower protocol overhead but does not itself guarantee delivery or ordering. IP addresses identify interfaces at the network layer; TCP and UDP ports identify services on a host. The OSI model is a useful troubleshooting reference: physical, data link, network, transport, session, presentation, and application. Start troubleshooting from the simplest layer that could explain the symptom and gather evidence before changing configuration. Relevant terms: TCP, UDP, IP, ports, OSI, packet loss, latency, connectivity.

## DNS and hostname resolution
DNS resolves hostnames to records such as IP addresses. If hostname resolution fails, compare access by hostname versus IP address, check the configured DNS servers, query the expected name with nslookup or Resolve-DnsName, and examine local resolver cache and DNS-client settings. A successful IP connection with a failed hostname lookup suggests a name-resolution issue, but verify the actual path and records before concluding. Relevant terms: DNS, hostname, nslookup, Resolve-DnsName, records, cache, resolver.

## DHCP and IP configuration
DHCP leases IP configuration such as an address, subnet mask, default gateway, and DNS servers. If a client cannot obtain a valid lease, check link or Wi-Fi connectivity, VLAN and relay configuration where applicable, DHCP-server scope capacity and service health, and the client's lease state. On Windows, ipconfig /all displays interface configuration and ipconfig /renew requests a lease renewal. Do not blindly assign a static address; first ensure it will not conflict with another host. Relevant terms: DHCP, lease, scope, gateway, subnet, ipconfig, relay.

## Subnets, default gateway, routing, and VLANs
A subnet mask or prefix determines which IP addresses are considered local. Traffic to a remote subnet normally goes to the default gateway, and routers forward packets using their routing tables. VLANs separate Layer 2 broadcast domains; communication between VLANs generally requires Layer 3 routing and appropriate policy. Check address, mask or prefix, gateway, route table, and VLAN assignment before changing routing or switching configuration. Relevant terms: subnet, CIDR, route, routing table, gateway, router, VLAN, switch, Layer 2, Layer 3.

## Connectivity troubleshooting: ping and traceroute
A basic connectivity workflow is to confirm the target and scope of the issue, inspect local IP configuration, test the loopback and local gateway when appropriate, test a known destination, and use traceroute or tracert to inspect the path. Ping failure alone does not prove a host is down because ICMP may be filtered. Record timestamps, source and destination, error text, and whether the issue affects one host or many. Relevant terms: ping, tracert, traceroute, packet loss, latency, unreachable, timeout.

## Firewalls: rules and stateful inspection
A firewall enforces traffic policy using attributes such as source and destination address, protocol, port, interface, and connection state. Stateful firewalls track connection state; rule order and implicit default actions can affect the outcome. Follow least privilege: permit only required traffic and avoid broad any-any rules. Before changing a rule, verify the intended source, destination, protocol, port, direction, rule order, logs, and change-approval requirements. Relevant terms: firewall, stateful, stateless, allow, deny, rule, policy, source, destination, port, inbound, outbound, ACL.

## Firewall troubleshooting and logs
When an application cannot connect, verify that the service is listening, confirm the expected source and destination IPs and ports, test reachability, inspect firewall logs for matching allow or deny events, and compare the traffic to the applicable rule. Check host firewall and network firewall separately. A timeout and an immediate connection refusal can indicate different failure points. Do not disable a firewall as the first troubleshooting step; use approved, narrow diagnostic changes and restore the intended policy. Relevant terms: firewall log, blocked, denied, timeout, refused, listening port, Windows Defender Firewall, security group.

## VPN, proxy, NAT, and web access
A VPN creates an encrypted tunnel and may change routes or DNS behavior. A proxy makes requests on behalf of a client and can introduce authentication, certificate, or policy issues. NAT translates address information, commonly between private and public networks. For access problems, determine whether the failure occurs only on VPN, only through a proxy, only for one destination, or only for one user; inspect routes, DNS, proxy configuration, certificates, and relevant logs. Relevant terms: VPN, proxy, NAT, TLS, certificate, HTTPS, web access, route.

## Windows operating system troubleshooting
For Windows issues, collect the exact error and scope, check relevant Event Viewer logs, verify service state, resource use, recent changes and patch status, then run targeted tests. Task Manager and Resource Monitor can help identify CPU, memory, disk, or process pressure. PowerShell commands should be scoped and reviewed before making changes. Useful commands include Get-Service, Get-Process, Get-NetIPConfiguration, Get-NetTCPConnection, ipconfig, and Test-NetConnection. Relevant terms: Windows, Event Viewer, service, PowerShell, process, CPU, memory, disk, patch.

## Linux operating system troubleshooting
For Linux issues, check service status, recent journal entries, process and resource usage, disk capacity, permissions, and network configuration. Common read-oriented commands include systemctl status, journalctl, ps, top, df -h, free -h, ip addr, ip route, ss -tulpn, and tail. Use elevated privileges only when needed and follow the organization's change process before modifying services or configuration. Relevant terms: Linux, systemd, systemctl, journalctl, permissions, disk, memory, process, ss, ip route.

## Services, listening ports, and application connectivity
A running application may still be unreachable because it is listening on the wrong interface, port, or address family, or because routing, name resolution, or a firewall blocks traffic. Confirm that the service is running, identify its listening socket, test from the local host and then from a client, and compare the expected port and protocol. On Windows, Get-NetTCPConnection and Test-NetConnection can help; on Linux, ss and curl can help. Relevant terms: service, listening, port, socket, connection refused, timeout, HTTP, HTTPS.

## Logs, incident triage, and ticket documentation
Start by clarifying impact, affected users or systems, start time, recent changes, and whether there is a workaround. Prioritize business impact and urgency, collect relevant logs and reproducible evidence, make only authorized changes, verify recovery, and document the outcome. Escalate when the issue exceeds access or experience, has broad impact, or risks data loss or security exposure. Avoid putting credentials, secrets, or unnecessary personal data in tickets. Relevant terms: incident, ticket, priority, P1, impact, logs, escalation, root cause, change, workaround.

## Patching, backups, and permissions
Apply patches under the organization's change-management process, including maintenance windows, backups or recovery plans, validation, and rollback considerations. Give accounts only the permissions required for their duties. Before changing permissions or security settings, identify the resource, intended user or service identity, required access, and approval. Verify the resulting state and document the change. Relevant terms: patching, update, backup, restore, permissions, least privilege, change management, rollback.

## Authentication and access basics
When a user cannot access a system, verify identity through approved processes, check account status, authentication method, group membership and permission scope, and review relevant authentication logs. Do not ask the user to reveal passwords or MFA codes. Distinguish authentication (who the user is) from authorization (what the user may do). Relevant terms: login, authentication, authorization, account locked, access denied, group membership, MFA.
