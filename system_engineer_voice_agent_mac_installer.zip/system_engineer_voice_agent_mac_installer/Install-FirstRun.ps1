$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
Set-Location $PSScriptRoot

$Root = $PSScriptRoot
$ModelName = 'qwen3:1.7b'
$WhisperModelName = 'ggml-tiny.en.bin'
$WhisperModelPath = Join-Path $Root "models\$WhisperModelName"
$WhisperDir = Join-Path $Root 'bin\whisper.cpp'
$WhisperExe = Join-Path $WhisperDir 'whisper-cli.exe'
$PythonExe = $null
$OllamaExe = $null

function Step([string]$Message) { Write-Host "`n==> $Message" -ForegroundColor Cyan }
function Refresh-ProcessPath {
    $machinePath = [Environment]::GetEnvironmentVariable('Path', 'Machine')
    $userPath = [Environment]::GetEnvironmentVariable('Path', 'User')
    $env:Path = "$machinePath;$userPath"
}
function Find-Winget {
    $c = Get-Command winget.exe -ErrorAction SilentlyContinue
    if ($c) { return $c.Source }
    $candidate = Join-Path $env:LOCALAPPDATA 'Microsoft\WindowsApps\winget.exe'
    if (Test-Path $candidate) { return $candidate }
    return $null
}
function Find-Python311 {
    Refresh-ProcessPath
    $launchers = @()
    $pyCommand = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($pyCommand) { $launchers += $pyCommand.Source }
    $launchers += @(
        (Join-Path $env:LOCALAPPDATA 'Programs\Python\Launcher\py.exe'),
        (Join-Path $env:WINDIR 'py.exe')
    )
    foreach ($launcher in ($launchers | Select-Object -Unique)) {
        if (-not (Test-Path $launcher)) { continue }
        try {
            $output = & $launcher -3.11 -c 'import sys; print(sys.executable)' 2>$null
            if ($LASTEXITCODE -eq 0 -and $output) {
                $exe = ([string]($output | Select-Object -Last 1)).Trim()
                if (Test-Path $exe) { return $exe }
            }
        } catch {}
    }
    $direct = @(
        (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python311\python.exe'),
        (Join-Path $env:ProgramFiles 'Python311\python.exe')
    )
    foreach ($exe in $direct) {
        if (Test-Path $exe) {
            try {
                $v = & $exe -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")' 2>$null
                if ($LASTEXITCODE -eq 0 -and ([string]($v | Select-Object -Last 1)).Trim() -eq '3.11') { return $exe }
            } catch {}
        }
    }
    return $null
}
function Find-Ollama {
    Refresh-ProcessPath
    $c = Get-Command ollama.exe -ErrorAction SilentlyContinue
    if ($c) { return $c.Source }
    $candidates = @(
        (Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama.exe'),
        (Join-Path $env:LOCALAPPDATA 'Ollama\ollama.exe'),
        (Join-Path $env:ProgramFiles 'Ollama\ollama.exe')
    )
    foreach ($p in $candidates) { if ($p -and (Test-Path $p)) { return $p } }
    return $null
}
function Install-WingetPackage([string]$Id, [string]$Name, [string]$WingetPath) {
    Write-Host "Installing $Name through Windows Package Manager. This may take a few minutes..." -ForegroundColor Yellow
    & $WingetPath install --id $Id --exact --silent --accept-package-agreements --accept-source-agreements --disable-interactivity
    $rc = $LASTEXITCODE
    Refresh-ProcessPath
    if ($rc -ne 0) { Write-Host "winget returned exit code $rc; checking whether $Name was installed anyway." -ForegroundColor Yellow }
}
function Ensure-OllamaServer([string]$Exe) {
    $api = 'http://127.0.0.1:11434/api/tags'
    try { $null = Invoke-RestMethod -Uri $api -Method Get -TimeoutSec 2; return } catch {}
    Write-Host 'Starting Ollama in the background...' -ForegroundColor Yellow
    try { Start-Process -FilePath $Exe -ArgumentList 'serve' -WindowStyle Hidden | Out-Null } catch {}
    for ($i = 0; $i -lt 90; $i++) {
        try { $null = Invoke-RestMethod -Uri $api -Method Get -TimeoutSec 2; return } catch { Start-Sleep -Seconds 1 }
    }
    throw 'Ollama did not start. Restart Windows and run Install.bat again. If the problem continues, open Ollama once from the Start menu.'
}
function Ensure-WhisperAssets {
    New-Item -ItemType Directory -Force -Path $WhisperDir, (Join-Path $Root 'models') | Out-Null
    if (-not (Test-Path $WhisperExe)) {
        Step 'Downloading the prebuilt whisper.cpp Windows x64 CPU executable'
        $zipPath = Join-Path $env:TEMP 'whisper-bin-x64-installer.zip'
        $extractPath = Join-Path $env:TEMP ('whisper-bin-x64-' + [guid]::NewGuid().ToString('N'))
        $url = 'https://github.com/ggml-org/whisper.cpp/releases/download/v1.8.3/whisper-bin-x64.zip'
        Invoke-WebRequest -Uri $url -OutFile $zipPath -UseBasicParsing
        Expand-Archive -Path $zipPath -DestinationPath $extractPath -Force
        $cli = Get-ChildItem -Path $extractPath -Filter 'whisper-cli.exe' -File -Recurse | Select-Object -First 1
        if (-not $cli) { throw 'The downloaded Whisper ZIP did not contain whisper-cli.exe.' }
        Copy-Item -Path $cli.FullName -Destination $WhisperDir -Force
        Get-ChildItem -Path $cli.DirectoryName -Filter '*.dll' -File | ForEach-Object { Copy-Item -Path $_.FullName -Destination $WhisperDir -Force }
        Remove-Item -Path $zipPath -Force -ErrorAction SilentlyContinue
        Remove-Item -Path $extractPath -Recurse -Force -ErrorAction SilentlyContinue
    } else { Write-Host 'Found cached whisper-cli.exe.' -ForegroundColor Green }

    if (-not (Test-Path $WhisperModelPath) -or (Get-Item $WhisperModelPath -ErrorAction SilentlyContinue).Length -lt 50000000) {
        Step 'Downloading the Whisper tiny.en model (about 75 MB)'
        if (Test-Path $WhisperModelPath) { Remove-Item $WhisperModelPath -Force }
        $url = 'https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-tiny.en.bin?download=true'
        Invoke-WebRequest -Uri $url -OutFile $WhisperModelPath -UseBasicParsing
        if ((Get-Item $WhisperModelPath).Length -lt 50000000) { throw 'Whisper model download appears incomplete. Run Install.bat again on a stable connection.' }
    } else { Write-Host 'Found cached Whisper model.' -ForegroundColor Green }
}
function Set-SarvamKey {
    $path = Join-Path $Root 'sarvam.env'
    $existing = ''
    if (Test-Path $path) {
        foreach ($line in (Get-Content $path -ErrorAction SilentlyContinue)) {
            if ($line -match '^\s*SARVAM_API_KEY\s*=(.*)$') { $existing = $Matches[1].Trim().Trim('"').Trim("'"); break }
        }
    }
    if ($existing -and $existing -notmatch '^(PASTE|YOUR_|put_your_real_key|placeholder)' ) {
        $choice = Read-Host 'A Sarvam API key is already saved. Keep it? [Y/n]'
        if ($choice.Trim().ToLowerInvariant() -ne 'n') { return }
    }
    Write-Host 'Get a key from https://dashboard.sarvam.ai/ .' -ForegroundColor Yellow
    $secure = Read-Host 'Paste your Sarvam API key (input is hidden)' -AsSecureString
    if ($secure.Length -lt 8) { throw 'No usable Sarvam API key was entered. Rerun Install.bat and enter the key when prompted.' }
    $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
    try { $key = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
    if ([string]::IsNullOrWhiteSpace($key) -or $key.Contains("`r") -or $key.Contains("`n")) { throw 'The Sarvam API key is empty or malformed.' }
    $content = "# Keep this file private; it contains your Sarvam API key.`r`nSARVAM_API_KEY=$key`r`n"
    [System.IO.File]::WriteAllText($path, $content, [System.Text.UTF8Encoding]::new($false))
    $key = $null
    Write-Host 'Saved the Sarvam key in sarvam.env (the key is not printed to the console).' -ForegroundColor Green
}
function Create-DesktopShortcut {
    try {
        $desktop = [Environment]::GetFolderPath('Desktop')
        if (-not $desktop) { return }
        $shortcutPath = Join-Path $desktop 'System Engineer Interview Demo.lnk'
        $shell = New-Object -ComObject WScript.Shell
        $shortcut = $shell.CreateShortcut($shortcutPath)
        $shortcut.TargetPath = Join-Path $env:WINDIR 'System32\cmd.exe'
        $shortcut.Arguments = '/c ""' + (Join-Path $Root 'run.bat') + '""'
        $shortcut.WorkingDirectory = $Root
        $shortcut.Description = 'Launch the local System Engineer interview training demo'
        $shortcut.Save()
        Write-Host 'Created a desktop shortcut.' -ForegroundColor Green
    } catch { Write-Host 'Could not create a desktop shortcut; use run.bat in the project folder.' -ForegroundColor Yellow }
}

try {
    Write-Host 'This installs local dependencies and model files; a stable internet connection is required.' -ForegroundColor White
    Write-Host 'Downloads include Python/Ollama installers, a Qwen model, Whisper executable/model, and Python packages.' -ForegroundColor White

    $winget = Find-Winget
    if (-not $winget) {
        throw 'Windows Package Manager (winget) was not found. On Windows 11, install or update App Installer from Microsoft Store, restart Windows, and run Install.bat again.'
    }

    Step 'Checking Python 3.11'
    $python = Find-Python311
    if (-not $python) {
        Install-WingetPackage -Id 'Python.Python.3.11' -Name 'Python 3.11 x64' -WingetPath $winget
        $python = Find-Python311
    }
    if (-not $python) { throw 'Python 3.11 was not detected after installation. Restart Windows, then run Install.bat again.' }
    $script:PythonExe = $python
    Write-Host "Using Python: $python" -ForegroundColor Green

    Step 'Checking Ollama'
    $ollama = Find-Ollama
    if (-not $ollama) {
        Install-WingetPackage -Id 'Ollama.Ollama' -Name 'Ollama' -WingetPath $winget
        $ollama = Find-Ollama
    }
    if (-not $ollama) { throw 'Ollama installation was not detected. Restart Windows, then run Install.bat again.' }
    $script:OllamaExe = $ollama
    Write-Host "Using Ollama: $ollama" -ForegroundColor Green

    Step 'Preparing the Python environment'
    if (-not (Test-Path (Join-Path $Root '.venv\Scripts\python.exe'))) {
        & $python -m venv (Join-Path $Root '.venv')
        if ($LASTEXITCODE -ne 0) { throw 'Could not create the Python virtual environment.' }
    }
    $venvPython = Join-Path $Root '.venv\Scripts\python.exe'
    & $venvPython -m pip install --upgrade pip
    if ($LASTEXITCODE -ne 0) { throw 'pip upgrade failed. Check internet access and rerun Install.bat.' }
    & $venvPython -m pip install -r (Join-Path $Root 'requirements.txt')
    if ($LASTEXITCODE -ne 0) { throw 'Python package installation failed. Check internet access and rerun Install.bat.' }

    Ensure-WhisperAssets

    Step 'Starting Ollama and downloading Qwen3 1.7B'
    Ensure-OllamaServer -Exe $ollama
    & $ollama pull $ModelName
    if ($LASTEXITCODE -ne 0) { throw "Could not download $ModelName. Check internet access and available disk space, then rerun Install.bat." }

    Step 'Configuring Sarvam voice'
    Set-SarvamKey

    New-Item -ItemType Directory -Force -Path (Join-Path $Root 'logs'), (Join-Path $Root 'media') | Out-Null
    Create-DesktopShortcut

    Write-Host ''
    Write-Host 'INSTALLATION COMPLETE' -ForegroundColor Green
    Write-Host 'Double-click run.bat or use the new desktop shortcut to open the meeting window.' -ForegroundColor Green
    Write-Host 'Keep this project folder private because sarvam.env contains your API key.' -ForegroundColor Yellow
    Write-Host 'Your colleagues should receive a clean copy of the original ZIP, not your configured folder.' -ForegroundColor Yellow
    exit 0
} catch {
    Write-Host ''
    Write-Host ('INSTALLATION FAILED: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host 'Correct the reported problem and run Install.bat again. Completed downloads and installed components will be reused.' -ForegroundColor Yellow
    exit 1
}
