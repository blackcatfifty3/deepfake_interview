$ErrorActionPreference = 'Stop'
$Model = 'qwen3:1.7b'
$Api = 'http://127.0.0.1:11434/api/tags'

function Test-OllamaApi {
    try {
        $r = Invoke-RestMethod -Uri $Api -Method Get -TimeoutSec 2
        return $true
    } catch { return $false }
}

if (Test-OllamaApi) { exit 0 }

$ollamaExe = $null
$cmd = Get-Command ollama.exe -ErrorAction SilentlyContinue
if ($cmd) { $ollamaExe = $cmd.Source }
if (-not $ollamaExe) {
    $candidates = @(
        (Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama.exe'),
        (Join-Path $env:LOCALAPPDATA 'Ollama\ollama.exe'),
        (Join-Path $env:ProgramFiles 'Ollama\ollama.exe'),
        (Join-Path ${env:ProgramFiles(x86)} 'Ollama\ollama.exe')
    )
    foreach ($p in $candidates) { if ($p -and (Test-Path $p)) { $ollamaExe = $p; break } }
}
if (-not $ollamaExe) {
    Write-Host 'Ollama was not found. Run Install.bat first.' -ForegroundColor Red
    exit 1
}

Write-Host 'Starting the local Ollama service...' -ForegroundColor Cyan
try { Start-Process -FilePath $ollamaExe -ArgumentList 'serve' -WindowStyle Hidden | Out-Null } catch {}
for ($i = 0; $i -lt 60; $i++) {
    if (Test-OllamaApi) {
        try {
            $tags = Invoke-RestMethod -Uri $Api -Method Get -TimeoutSec 4
            $found = @($tags.models | Where-Object { $_.name -eq $Model -or $_.name -like "$Model*" }).Count -gt 0
            if (-not $found) {
                Write-Host "The local model $Model is not installed. Run Install.bat to repair setup." -ForegroundColor Red
                exit 1
            }
        } catch {
            Write-Host 'Ollama responded, but its model list could not be read.' -ForegroundColor Red
            exit 1
        }
        exit 0
    }
    Start-Sleep -Seconds 1
}
Write-Host 'Ollama did not start in time. Close duplicate Ollama processes or restart Windows, then try run.bat again.' -ForegroundColor Red
exit 1
