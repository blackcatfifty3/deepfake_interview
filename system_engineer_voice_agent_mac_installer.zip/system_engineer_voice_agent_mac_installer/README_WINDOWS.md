# System Engineer Interview Demo — Windows Setup Guide

This guide walks me through installing and running my local System Engineer interview simulation on Windows 11. The interface is a Zoom-inspired **training simulation**; it does not connect to Zoom.

## What I’m setting up

- **Whisper.cpp + `tiny.en`** for local English speech recognition.
- **Ollama + Qwen3 1.7B** for local answer generation.
- **Sarvam Bulbul v4 Flash** for spoken answers. Sarvam requires internet access and an API key.
- A browser-based meeting UI with a simulated camera-permission prompt, an actual microphone permission request, a candidate-photo fade-in, and a **Start Call** button.

The interview window does not show transcripts, answers, or thinking-progress captions. The simulated camera prompt does not access a physical camera. The microphone is captured after I grant permissions and click **Start Call**.

## Before I begin

I need:

- Windows 11 x64 with internet access during installation.
- A working microphone and speakers/headphones.
- Several gigabytes of free disk space for Python packages and the Qwen model.
- Windows Package Manager (`winget`). It is normally installed through **App Installer** from Microsoft Store.
- My own Sarvam API key, available from <https://dashboard.sarvam.ai/>.

I should extract the ZIP to a folder I can write to, for example:

```text
C:\LocalDemos\SystemEngineerInterview
```

I should **not** extract it into `C:\Program Files`.

## One-time installation

1. I download the Windows installer ZIP and choose **Extract All**.
2. I open the extracted folder.
3. I double-click **`Install.bat`**.
4. The installer checks for and installs Python 3.11 x64 and Ollama through `winget` if needed.
5. It creates a local `.venv`, installs Python dependencies, downloads the prebuilt Windows x64 Whisper executable and required DLLs, and downloads the Whisper `tiny.en` model.
6. It starts Ollama and downloads `qwen3:1.7b`.
7. When prompted, I paste my Sarvam API key. The input is hidden. The installer saves it in `sarvam.env` in this project folder.
8. When the installer reports **INSTALLATION COMPLETE**, I can close the window. It may also create a desktop shortcut.

The initial setup downloads several components and may take a while. I keep the computer connected to the internet. If a download is interrupted, I can run `Install.bat` again; it reuses already-installed components and valid cached files where possible.

### If `winget` is missing

I install or update **App Installer** from the Microsoft Store, restart Windows, then double-click `Install.bat` again.

## Each time I run the interview

1. I double-click **`run.bat`** or the desktop shortcut.
2. The meeting-style window opens in my browser.
3. I click **Allow** on the simulated camera prompt; it only enables the photo fade-in and does not access my camera.
4. I grant the browser microphone permission when asked. If Windows blocks microphone access, I check **Settings → Privacy & security → Microphone** and allow access for the browser/desktop apps as appropriate.
5. I click **Start Call**. Only then does the interview start listening.
6. I speak a question, pause briefly, and listen to the answer. I can use the UI’s call controls to mute or end the session.

To stop the local application, I close the meeting window or stop the backend if the session remains active.

## Add or change the candidate photo

I can place a photo I have permission to use in the `media` folder, named `candidate.jpg`. The UI also supports `.jpeg`, `.png`, and `.webp` with the `candidate` basename. If I do not add a photo, the UI shows the placeholder.

## Voice settings

The included configuration uses:

```python
SARVAM_LANGUAGE_CODE = "en-IN"
SARVAM_SPEAKER = "aayan_hi_conversational"
SARVAM_MODEL = "bulbul:v4-flash"
SARVAM_PACE = 1.0
SARVAM_SAMPLE_RATE = 24000
```

The selected Aayan voice is designed for Hindi, so English speech may have a Hindi-influenced accent. I can change the speaker in `config.py` after checking the current official voice catalogue: <https://docs.sarvam.ai/api/api-guides-tutorials/text-to-speech/voices>.

## What stays local, and what goes to Sarvam

- **Runs on my computer:** microphone capture, Whisper transcription, Qwen reasoning, and local knowledge lookup.
- **Sent to Sarvam:** the generated answer text, so Sarvam can synthesize speech. An internet connection and available API credits are required for spoken responses.

My `sarvam.env` contains a secret. I keep it private and do not upload it to public repositories or share a configured project folder. If I need to distribute the app, I use a clean ZIP with no real API key; each installation should set up its own key through the installer.

## Troubleshooting

- **The installer cannot find `winget`:** install/update App Installer from Microsoft Store, restart Windows, and rerun `Install.bat`.
- **Python or Ollama is not detected after installation:** restart Windows, then rerun `Install.bat`.
- **Ollama does not start:** open Ollama from the Start menu once, then rerun `run.bat`. If needed, rerun `Install.bat`.
- **Qwen download fails:** check internet and disk space, then rerun `Install.bat`.
- **Whisper is missing or broken:** rerun `Install.bat` to restore the executable and model.
- **Sarvam returns 401/403:** open `sarvam.env` and verify that the key is correct and active. Never paste the key into chat or a screenshot.
- **Sarvam returns 429:** check API credits and usage limits in the Sarvam dashboard.
- **The microphone does not work:** allow microphone access in Windows settings and browser site permissions, then close and reopen the app.
- **The candidate photo is missing:** put a supported image in `media` using the `candidate` filename, then reopen the UI.
- **The app fails to start:** inspect `logs\voice_agent.log` if it exists and rerun the installer if any component is missing.

## Official downloads and documentation

- Python for Windows: <https://www.python.org/downloads/windows/>
- Ollama for Windows: <https://ollama.com/download/windows>
- Qwen3 1.7B: <https://ollama.com/library/qwen3:1.7b>
- Whisper.cpp releases: <https://github.com/ggml-org/whisper.cpp/releases>
- Sarvam dashboard: <https://dashboard.sarvam.ai/>
- Sarvam Bulbul documentation: <https://docs.sarvam.ai/api/getting-started/models/bulbul>
