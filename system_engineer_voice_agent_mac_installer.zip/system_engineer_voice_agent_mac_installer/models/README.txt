Install-FirstRun.ps1 downloads ggml-tiny.en.bin into this folder.
