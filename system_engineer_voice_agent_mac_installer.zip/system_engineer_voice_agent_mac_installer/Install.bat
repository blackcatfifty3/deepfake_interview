@echo off
setlocal
cd /d "%~dp0"
echo.
echo ================================================================
echo  System Engineer Interview Demo - First-Run Installer
echo ================================================================
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-FirstRun.ps1"
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" (
  echo INSTALLATION FAILED. Read the error above, fix the issue, then run Install.bat again.
  pause
  exit /b %RC%
)
echo Installation completed. You can now launch the interview with run.bat.
pause
exit /b 0
