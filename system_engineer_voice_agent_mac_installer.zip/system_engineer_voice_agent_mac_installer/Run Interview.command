#!/bin/bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
mkdir -p "$ROOT/logs"
URL="http://127.0.0.1:8765/"

if [[ ! -x "$ROOT/.venv/bin/python" ]]; then
  echo 'Setup has not completed. Double-click Install.command first.'
  read -r -p 'Press Return to close. ' _ || true
  exit 1
fi
if [[ ! -x "$ROOT/bin/whisper.cpp/whisper-cli" || ! -s "$ROOT/models/ggml-tiny.en.bin" ]]; then
  echo 'Whisper is missing. Double-click Install.command to repair setup.'
  read -r -p 'Press Return to close. ' _ || true
  exit 1
fi

# If the UI is already running, just bring it back up in the browser.
if curl -fsS --max-time 1 "$URL" >/dev/null 2>&1; then
  open "$URL"
  exit 0
fi

# Make sure local Ollama responds; start it from the bundled Ollama.app if needed.
if ! curl -fsS --max-time 2 http://127.0.0.1:11434/api/tags >/dev/null 2>&1; then
  OLLAMA_BIN=""
  if [[ -f "$ROOT/.ollama_bin_path" ]]; then OLLAMA_BIN="$(cat "$ROOT/.ollama_bin_path")"; fi
  if [[ -x "$OLLAMA_BIN" ]]; then
    nohup "$OLLAMA_BIN" serve >> "$ROOT/logs/ollama.log" 2>&1 < /dev/null &
  else
    for candidate in "$HOME/Applications/Ollama.app/Contents/Resources/ollama" "/Applications/Ollama.app/Contents/Resources/ollama"; do
      if [[ -x "$candidate" ]]; then nohup "$candidate" serve >> "$ROOT/logs/ollama.log" 2>&1 < /dev/null & break; fi
    done
  fi
  for _ in $(seq 1 60); do
    if curl -fsS --max-time 2 http://127.0.0.1:11434/api/tags >/dev/null 2>&1; then break; fi
    sleep 1
  done
fi
if ! curl -fsS --max-time 2 http://127.0.0.1:11434/api/tags >/dev/null 2>&1; then
  echo 'Ollama is not running. Rerun Install.command or open Ollama.app once.'
  read -r -p 'Press Return to close. ' _ || true
  exit 1
fi

# Keep the backend running in this Terminal session so macOS can present microphone permissions.
echo 'Starting local interview backend. The meeting window will open shortly.'
echo 'Keep this Terminal window open during the interview. Press Ctrl+C here to stop the backend.'
exec "$ROOT/.venv/bin/python" "$ROOT/ui_app.py"
