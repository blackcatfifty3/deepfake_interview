# Compatibility wrapper: the one-time setup now installs the full toolchain.
& (Join-Path $PSScriptRoot 'Install-FirstRun.ps1')
exit $LASTEXITCODE
