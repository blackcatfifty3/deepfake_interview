#!/bin/bash
ROOT="$(cd "$(dirname "$0")" && pwd)"
PID_FILE="$ROOT/logs/ui_app.pid"
# Normal launch is in the Terminal attached to Run Interview.command; Ctrl+C there stops it.
# This helper stops an optional detached launch only if the command matches this project.
if [[ -f "$PID_FILE" ]]; then
  PID="$(cat "$PID_FILE" 2>/dev/null || true)"
  if [[ "$PID" =~ ^[0-9]+$ ]] && ps -p "$PID" -o command= 2>/dev/null | grep -F "$ROOT/ui_app.py" >/dev/null; then
    kill "$PID" 2>/dev/null || true
    rm -f "$PID_FILE"
    echo 'Interview backend stopped.'
    exit 0
  fi
fi
echo 'If the interview backend is running in Terminal, press Ctrl+C in that Terminal window to stop it.'
read -r -p 'Press Return to close. ' _ || true
