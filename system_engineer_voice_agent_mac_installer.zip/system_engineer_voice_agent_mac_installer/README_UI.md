# Meeting UI notes

The UI is served locally at `http://127.0.0.1:8765/`. It mimics a meeting window for a clearly labelled training simulation and is not connected to the Zoom service.

- Camera prompt: simulated; it does not invoke the camera API.
- Microphone prompt: real browser permission check.
- Audio capture: Python uses the Windows default input device after Start Call.
- Candidate image: `media\candidate.jpg`, `.jpeg`, `.png`, or `.webp`.
- No transcript, response text, or thinking caption is displayed in the UI.
- `run.bat` checks/starts Ollama, then runs the UI using `pythonw.exe` to avoid a persistent console.
