@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\pythonw.exe" (
  echo Setup has not completed. Double-click Install.bat first.
  pause
  exit /b 1
)
if not exist "ui\index.html" (
  echo UI files are missing. Re-extract the project ZIP.
  pause
  exit /b 1
)
if not exist "bin\whisper.cpp\whisper-cli.exe" (
  echo Whisper is missing. Double-click Install.bat to repair setup.
  pause
  exit /b 1
)
if not exist "models\ggml-tiny.en.bin" (
  echo Whisper model is missing. Double-click Install.bat to repair setup.
  pause
  exit /b 1
)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-Ollama.ps1"
if errorlevel 1 (
  echo Could not start Ollama. Read the message above and rerun Install.bat if needed.
  pause
  exit /b 1
)
start "" "%~dp0.venv\Scripts\pythonw.exe" "%~dp0ui_app.py"
exit /b 0
