# System Engineer Interview Demo — macOS Setup Guide

This guide walks me through installing and running my local System Engineer interview simulation on a Mac. The interface is a Zoom-inspired **training simulation**; it does not connect to Zoom.

## What I’m setting up

- **Whisper.cpp + `tiny.en`** for local English speech recognition.
- **Ollama + Qwen3 1.7B** for local answer generation.
- **Sarvam Bulbul v4 Flash** for spoken answers. Sarvam requires internet access and an API key.
- A browser-based meeting UI with a simulated camera-permission prompt, an actual microphone permission request, a candidate-photo fade-in, and a **Start Call** button.

The interview window does not show transcripts, answers, or thinking-progress captions. The simulated camera prompt does not access a physical camera. The microphone is captured after I grant permissions and click **Start Call**.

## Before I begin

I need:

- macOS **Sonoma 14 or later** for the included Ollama installation flow.
- An Apple Silicon Mac is recommended; Intel Macs may be considerably slower for local AI inference.
- Internet access for installation, model downloads, and Sarvam voice synthesis.
- A working microphone and speakers/headphones.
- Several gigabytes of free disk space.
- My own Sarvam API key from <https://dashboard.sarvam.ai/>.

The installer may need Apple Command Line Tools and Homebrew. If macOS asks to install Command Line Tools, I complete that prompt first and then rerun the installer.

I extract the ZIP into a writable folder, for example:

```text
~/Documents/SystemEngineerInterview
```

## One-time installation

1. I download the macOS installer ZIP and extract it to the folder I chose.
2. I open the extracted folder in Finder.
3. I double-click **`Install.command`**. If macOS blocks it, I Control-click the file, select **Open**, and approve it. I should run it only if I trust the source of the package.
4. The installer checks for Apple Command Line Tools and installs Homebrew if needed.
5. It installs Python 3.11, `whisper.cpp`, and PortAudio through Homebrew.
6. If Ollama is missing, it downloads the official Ollama app and places it in `~/Applications/Ollama.app`, then starts the local Ollama service.
7. It downloads `qwen3:1.7b`, links the local `whisper-cli` binary into the project, and downloads the Whisper `tiny.en` model.
8. It creates `.venv`, installs Python dependencies, and asks me for my Sarvam API key with hidden input. The key is saved in `sarvam.env` inside the project folder.
9. When it reports **INSTALLATION COMPLETE**, I can close the installer window.

The initial setup may download several gigabytes and take a while. I keep my Mac connected to the internet. If a download is interrupted, I can run `Install.command` again; it reuses installed components and valid cached files where possible.

### If macOS blocks `Install.command`

I Control-click `Install.command`, choose **Open**, and confirm. If Apple Command Line Tools are missing, I complete their installation, then run `Install.command` again.

## Each time I run the interview

1. I double-click **`Run Interview.command`**. If macOS blocks it, I Control-click and choose **Open**.
2. I keep the Terminal window open while the backend runs. The meeting-style window should open in Chrome/Edge app mode if available, or otherwise in my default browser.
3. I click **Allow** on the simulated camera prompt; this only enables the photo fade-in and does not access my camera.
4. I grant microphone permission in the browser. Since Python captures audio locally, macOS may also need microphone permission for Terminal or Python under **System Settings → Privacy & Security → Microphone**.
5. I click **Start Call**. Only then does the interview start listening.
6. I speak a question, pause briefly, and listen to the answer.

To stop the backend, I return to its Terminal window and press **Ctrl+C**.

## Add or change the candidate photo

I can place a photo I have permission to use in the `media` folder, named `candidate.jpg`. The UI also supports `.jpeg`, `.png`, and `.webp` with the `candidate` basename. If I do not add a photo, the UI shows the placeholder.

## Voice settings

The included configuration uses:

```python
SARVAM_LANGUAGE_CODE = "en-IN"
SARVAM_SPEAKER = "aayan_hi_conversational"
SARVAM_MODEL = "bulbul:v4-flash"
SARVAM_PACE = 1.0
SARVAM_SAMPLE_RATE = 24000
```

The selected Aayan voice is designed for Hindi, so English speech may have a Hindi-influenced accent. I can check other currently available voices in Sarvam’s official catalogue: <https://docs.sarvam.ai/api/api-guides-tutorials/text-to-speech/voices>.

## What stays local, and what goes to Sarvam

- **Runs on my Mac:** microphone capture, Whisper transcription, Qwen reasoning, and local knowledge lookup.
- **Sent to Sarvam:** the generated answer text, so Sarvam can synthesize speech. An internet connection and available API credits are required for spoken responses.

My `sarvam.env` contains a secret. I keep it private and do not upload it to public repositories or share a configured project folder. I only distribute a clean ZIP with no real API key; the installer prompts for a key during setup.

## Troubleshooting

- **Homebrew or Command Line Tools fail:** complete the macOS software update or Command Line Tools prompt, then rerun `Install.command`.
- **Ollama does not start:** open `~/Applications/Ollama.app` once, or reinstall from <https://ollama.com/download/mac>, then rerun `Install.command`. Check `logs/ollama.log` if present.
- **Whisper is missing:** rerun `Install.command` to reinstall/relink the Homebrew binary and download the model if needed.
- **Qwen download fails:** check internet and disk space, then rerun `Install.command`.
- **Sarvam returns 401/403:** verify the key in `sarvam.env` and that it is active. Never paste the key into chat or screenshots.
- **Sarvam returns 429:** check API credits and usage limits in the Sarvam dashboard.
- **The microphone is blocked:** check **System Settings → Privacy & Security → Microphone**. Allow the browser and Terminal/Python as required, then fully quit and reopen the app.
- **The candidate photo is missing:** put a supported image in `media` using the `candidate` filename, then reopen the UI.
- **The app is slow:** local Qwen inference depends on RAM and CPU. Apple Silicon is recommended; older Intel Macs may respond slowly.

## Official downloads and documentation

- Ollama for Mac: <https://ollama.com/download/mac>
- Ollama macOS requirements: <https://github.com/ollama/ollama/blob/main/docs/macos.mdx>
- Homebrew Whisper.cpp: <https://formulae.brew.sh/formula/whisper.cpp>
- Qwen3 1.7B: <https://ollama.com/library/qwen3:1.7b>
- Sarvam dashboard: <https://dashboard.sarvam.ai/>
- Sarvam Bulbul documentation: <https://docs.sarvam.ai/api/getting-started/models/bulbul>
