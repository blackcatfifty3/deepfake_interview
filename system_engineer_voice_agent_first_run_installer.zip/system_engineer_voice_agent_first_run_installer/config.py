"""Configuration for the System Engineer voice-agent demo."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent

# whisper.cpp: place whisper-cli.exe and all companion DLLs in this folder.
WHISPER_EXE = ROOT / "bin" / "whisper.cpp" / "whisper-cli.exe"
WHISPER_MODEL = ROOT / "models" / "ggml-tiny.en.bin"

# Fast CPU profile; change to qwen3:4b for stronger technical answers at higher latency.
OLLAMA_URL = "http://127.0.0.1:11434/api/chat"
OLLAMA_MODEL = "qwen3:1.7b"

# Sarvam Bulbul v4 Flash cloud text-to-speech.
SARVAM_API_URL = "https://api.sarvam.ai/text-to-speech"
SARVAM_MODEL = "bulbul:v4-flash"
SARVAM_LANGUAGE_CODE = "en-IN"
# Conversational English voice; audition other voices in Sarvam's voice catalog.
SARVAM_SPEAKER = "aayan_hi_conversational"
SARVAM_PACE = 1.0
SARVAM_SAMPLE_RATE = 24000

# Microphone capture / voice activity thresholds.
SAMPLE_RATE = 16000
BLOCK_SIZE = 1024
VOICE_RMS_THRESHOLD = 380
END_SILENCE_SECONDS = 0.75
START_TIMEOUT_SECONDS = 45
MAX_UTTERANCE_SECONDS = 30
MIN_SPEECH_SECONDS = 0.30

# Short answers keep local reasoning and TTS usage latency modest.
MAX_ANSWER_TOKENS = 100
MAX_CONTEXT_CHARS = 3500
WHISPER_THREADS = None  # Auto-select based on available CPU cores.

FALLBACK_RESPONSE = "Sorry, that isn't something I've come across in my experience."
JOINING_RESPONSE = (
    "My joining date would depend on the notice period and the agreed start date. "
    "I can confirm the exact date once those details are finalized."
)
