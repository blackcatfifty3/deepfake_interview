"""Local Zoom-inspired training UI for the System Engineer voice demo.

Binds to loopback only. The camera permission prompt is simulated; no camera API is
called. Browser microphone permission is real, and the voice engine captures audio
locally through the default Windows microphone device.
"""
from __future__ import annotations

import json
import mimetypes
import os
import socket
import subprocess
import sys
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

import app as engine

ROOT = Path(__file__).resolve().parent
UI_DIR = ROOT / "ui"
MEDIA_DIR = ROOT / "media"
LOG_DIR = ROOT / "logs"
LOG_DIR.mkdir(exist_ok=True)
LOG_PATH = LOG_DIR / "voice_agent.log"
HOST = "127.0.0.1"
PORT = 8765

# Keep all transcript/answer output away from the UI and avoid saving actual
# interviewer/agent utterances in the log file. Other diagnostics are recorded.
class RedactingLog:
    def __init__(self, path: Path):
        self.handle = path.open("a", encoding="utf-8", buffering=1)
        self.lock = threading.Lock()
        self._pending = ""

    def write(self, value):
        if not value:
            return 0
        self._pending += str(value)
        while "\n" in self._pending:
            line, self._pending = self._pending.split("\n", 1)
            if "Interviewer:" in line:
                line = "[interviewer transcript redacted]"
            elif "Candidate:" in line:
                line = "[candidate answer redacted]"
            with self.lock:
                self.handle.write(line + "\n")
        return len(value)

    def flush(self):
        with self.lock:
            self.handle.flush()


_logger = RedactingLog(LOG_PATH)
sys.stdout = _logger
sys.stderr = _logger

_state_lock = threading.RLock()
_stop_event = threading.Event()
_mute_event = threading.Event()
_preflight_done = threading.Event()
_state = {
    "active": False,
    "muted": False,
    "error": "",
    "ended_at": 0.0,
    "preflight_ok": False,
    "preflight_error": "",
}
_worker: threading.Thread | None = None


def _preflight() -> None:
    try:
        if not engine.load_sarvam_api_key():
            raise RuntimeError("Sarvam API key is missing. Check sarvam.env.")
        engine.check_local_services()
        engine.warmup_ollama()
        with _state_lock:
            _state["preflight_ok"] = True
            _state["preflight_error"] = ""
        print("UI preflight completed. Interview remains stopped until Start Call is clicked.", flush=True)
    except Exception as exc:
        with _state_lock:
            _state["preflight_ok"] = False
            _state["preflight_error"] = str(exc)
        print(f"Preflight failed: {exc}", flush=True)
    finally:
        _preflight_done.set()


def _interview_worker() -> None:
    history: list[dict[str, str]] = []
    key = engine.load_sarvam_api_key()
    try:
        while not _stop_event.is_set():
            if _mute_event.is_set():
                time.sleep(0.12)
                continue
            audio = engine.record_until_silence(stop_event=_stop_event, mute_event=_mute_event)
            if _stop_event.is_set():
                break
            if _mute_event.is_set() or audio is None:
                continue
            question = engine.transcribe_audio(audio)
            if not question:
                continue
            if question.strip().lower().strip(" .!?") in {"exit", "quit", "stop", "stop listening", "end interview"}:
                break
            answer = engine.get_response(question, history)
            if answer == "__EXIT__":
                break
            engine.speak(answer, key)
            if engine.is_out_of_role_request(question):
                history.clear()
            else:
                history.extend([
                    {"role": "user", "content": question},
                    {"role": "assistant", "content": answer},
                ])
                history = history[-4:]
    except Exception as exc:
        print(f"Interview worker error: {exc}", flush=True)
        with _state_lock:
            _state["error"] = "The call ended unexpectedly. Check logs\\voice_agent.log."
    finally:
        _stop_event.set()
        with _state_lock:
            _state["active"] = False
            _state["muted"] = False
            _state["ended_at"] = time.time()
        _mute_event.clear()
        print("Interview worker stopped.", flush=True)


def _photo_path() -> Path | None:
    for name in ("candidate.jpg", "candidate.jpeg", "candidate.png", "candidate.webp"):
        path = MEDIA_DIR / name
        if path.is_file():
            return path
    return None


class Handler(BaseHTTPRequestHandler):
    server_version = "LocalMeetingDemo/1.0"

    def log_message(self, _format, *_args):
        # Do not expose browser requests or anything in the UI.
        return

    def _send(self, status: int, body: bytes, content_type: str = "application/json; charset=utf-8"):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy", "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; media-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, status: int, obj):
        self._send(status, json.dumps(obj).encode("utf-8"))

    def do_GET(self):
        route = urlparse(self.path).path
        if route in ("/", "/index.html"):
            path = UI_DIR / "index.html"
            return self._send(200, path.read_bytes(), "text/html; charset=utf-8")
        if route == "/placeholder.svg":
            path = UI_DIR / "placeholder.svg"
            return self._send(200, path.read_bytes(), "image/svg+xml; charset=utf-8")
        if route == "/candidate-photo":
            path = _photo_path()
            if path is None:
                path = UI_DIR / "placeholder.svg"
            content_type = mimetypes.guess_type(str(path))[0] or "application/octet-stream"
            return self._send(200, path.read_bytes(), content_type)
        if route == "/api/state":
            with _state_lock:
                result = {
                    "active": _state["active"],
                    "muted": _state["muted"],
                    "error": _state["error"],
                    "preflight_ok": _state["preflight_ok"],
                    "preflight_error": _state["preflight_error"],
                }
            return self._json(200, result)
        return self._json(404, {"error": "Not found"})

    def do_POST(self):
        route = urlparse(self.path).path
        try:
            length = int(self.headers.get("Content-Length", "0"))
            payload = json.loads(self.rfile.read(length) or b"{}")
        except Exception:
            return self._json(400, {"error": "Invalid request"})

        if route == "/api/start":
            if not payload.get("micGranted") or not payload.get("cameraMockAllowed"):
                return self._json(400, {"error": "Allow microphone and camera simulation before starting."})
            if not _preflight_done.wait(timeout=240):
                return self._json(503, {"error": "Local services are still starting. Try again shortly."})
            with _state_lock:
                if not _state["preflight_ok"]:
                    return self._json(503, {"error": _state["preflight_error"] or "Startup check failed."})
                if _state["active"]:
                    return self._json(200, {"ok": True, "active": True})
                _state["error"] = ""
                _state["active"] = True
                _state["muted"] = False
                _stop_event.clear()
                _mute_event.clear()
                global _worker
                _worker = threading.Thread(target=_interview_worker, name="interview-worker", daemon=True)
                _worker.start()
            return self._json(200, {"ok": True, "active": True})

        if route == "/api/end":
            _stop_event.set()
            _mute_event.clear()
            try:
                # Stop any currently playing answer. If synthesis is currently in-flight,
                # the worker will exit as soon as it reaches its next stop check.
                engine.sd.stop()
            except Exception:
                pass
            with _state_lock:
                _state["muted"] = False
            return self._json(200, {"ok": True, "stopping": True})

        if route == "/api/mute":
            muted = bool(payload.get("muted"))
            if muted:
                _mute_event.set()
            else:
                _mute_event.clear()
            with _state_lock:
                _state["muted"] = muted
            return self._json(200, {"ok": True, "muted": muted})

        return self._json(404, {"error": "Not found"})


def _open_app_window(url: str):
    # Prefer a chromeless app window. Fall back to the default browser if neither is found.
    candidates = [
        os.path.join(os.environ.get("PROGRAMFILES", r"C:\Program Files"), "Microsoft", "Edge", "Application", "msedge.exe"),
        os.path.join(os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)"), "Microsoft", "Edge", "Application", "msedge.exe"),
        os.path.join(os.environ.get("LOCALAPPDATA", ""), "Google", "Chrome", "Application", "chrome.exe"),
        os.path.join(os.environ.get("PROGRAMFILES", r"C:\Program Files"), "Google", "Chrome", "Application", "chrome.exe"),
    ]
    for binary in candidates:
        if binary and os.path.isfile(binary):
            subprocess.Popen([binary, f"--app={url}", "--start-maximized"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return
    webbrowser.open(url, new=1)


def main():
    MEDIA_DIR.mkdir(exist_ok=True)
    try:
        server = ThreadingHTTPServer((HOST, PORT), Handler)
    except OSError as exc:
        print(f"Could not bind local UI on http://{HOST}:{PORT}: {exc}", flush=True)
        return 1

    threading.Thread(target=_preflight, name="preflight", daemon=True).start()
    url = f"http://{HOST}:{PORT}/"
    print(f"Meeting UI running at {url}", flush=True)
    threading.Timer(0.9, _open_app_window, args=(url,)).start()
    try:
        server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        pass
    finally:
        _stop_event.set()
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
